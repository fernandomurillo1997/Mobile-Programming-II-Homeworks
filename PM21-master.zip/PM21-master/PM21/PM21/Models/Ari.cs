﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PM21.Models
{
    public class Ari
    {
        public int Sum { set; get; }
        public int Resta { set; get; }
        public int Div { set; get; }
        public int Milti { set; get; }

    }
}
