﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PM1_2.Models
{
    public class Personas
    {
        public String name { set; get; }
        public String apellidos { set; get; }
        public int edad { set; get; }
        public String correo { set; get; }
    }
}
